USE db_adspitcher;

insert into `tb_business_badge_details`(`col_badgelevelid`,`col_badgename`) values (1,'Poor');
insert into `tb_business_badge_details`(`col_badgelevelid`,`col_badgename`) values (2,'Good');
insert into `tb_business_badge_details`(`col_badgelevelid`,`col_badgename`) values (3,'Average');
insert into `tb_business_badge_details`(`col_badgelevelid`,`col_badgename`) values (4,'Very Good');
insert into `tb_business_badge_details`(`col_badgelevelid`,`col_badgename`) values (5,'Star Performer');
