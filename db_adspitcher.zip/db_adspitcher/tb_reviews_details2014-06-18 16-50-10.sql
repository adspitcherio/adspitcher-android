USE db_adspitcher;

insert into `tb_reviews_details`(`col_reviewid`,`col_reviewtext`) values (1,'Mind blowing collection by Benetton.');
insert into `tb_reviews_details`(`col_reviewid`,`col_reviewtext`) values (2,'Must visit sale, before the collection ends.');
insert into `tb_reviews_details`(`col_reviewid`,`col_reviewtext`) values (3,'Friends please go and visit the store.');
insert into `tb_reviews_details`(`col_reviewid`,`col_reviewtext`) values (4,'Horrible collection.');
insert into `tb_reviews_details`(`col_reviewid`,`col_reviewtext`) values (5,'Should try launching new collection. Instead of giving useless sale.');
