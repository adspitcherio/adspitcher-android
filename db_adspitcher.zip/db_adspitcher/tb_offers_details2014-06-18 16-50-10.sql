USE db_adspitcher;

insert into `tb_offers_details`(`col_offer_id`,`col_offer_desc`,`col_offer_image`,`col_thumbs_up`,`col_thumbs_down`,`col_businessid`,`col_offerstartdate`,`col_offerenddate`) values (1,'SEASONAL SALE UPTO 50% 18 JUL 2014 - 30 JUL 2014. Available at Ambience Mall Gurgaon.',nullnullSystem.Byte[],0,0,1,'18/07/2014','30/07/2014');
insert into `tb_offers_details`(`col_offer_id`,`col_offer_desc`,`col_offer_image`,`col_thumbs_up`,`col_thumbs_down`,`col_businessid`,`col_offerstartdate`,`col_offerenddate`) values (2,'FLAT 20% OFF on KIDSWEAR United Colors Of Benetton.',nullnullSystem.Byte[],0,0,2,null,'20/07/2014');
insert into `tb_offers_details`(`col_offer_id`,`col_offer_desc`,`col_offer_image`,`col_thumbs_up`,`col_thumbs_down`,`col_businessid`,`col_offerstartdate`,`col_offerenddate`) values (3,'SEASONAL SALE FLAT 70% 5 JUL 2014 - 10 JUL 2014.',nullnullSystem.Byte[],0,0,2,'05/07/2014','10/07/2014');
