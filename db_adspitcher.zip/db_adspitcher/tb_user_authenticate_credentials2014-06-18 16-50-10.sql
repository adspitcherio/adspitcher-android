USE db_adspitcher;

insert into `tb_user_authenticate_credentials`(`col_userid`,`col_username`,`col_userpassword`) values (1,'testa','testa');
insert into `tb_user_authenticate_credentials`(`col_userid`,`col_username`,`col_userpassword`) values (2,'testb','testb');
insert into `tb_user_authenticate_credentials`(`col_userid`,`col_username`,`col_userpassword`) values (3,'testc','testc');
insert into `tb_user_authenticate_credentials`(`col_userid`,`col_username`,`col_userpassword`) values (4,'testd','testd');
