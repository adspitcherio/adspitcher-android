USE db_adspitcher;

insert into `tb_user_badge_details`(`col_badgelevelid`,`col_badgename`,`col_badgerequiredcredits`) values (1,'Hunter',10);
insert into `tb_user_badge_details`(`col_badgelevelid`,`col_badgename`,`col_badgerequiredcredits`) values (2,'Learner',500);
insert into `tb_user_badge_details`(`col_badgelevelid`,`col_badgename`,`col_badgerequiredcredits`) values (3,'Shopaholic',1000);
