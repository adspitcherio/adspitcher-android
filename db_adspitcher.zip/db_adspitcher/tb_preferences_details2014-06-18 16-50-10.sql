USE db_adspitcher;

insert into `tb_preferences_details`(`col_userid`,`col_preferred_locations`,`col_preferred_businesses`,`col_preferred_categories`) values (1,'Delhi, Noida, Gurgaon','Adidas, Biba','Shoes, Kurtis');
insert into `tb_preferences_details`(`col_userid`,`col_preferred_locations`,`col_preferred_businesses`,`col_preferred_categories`) values (2,'Gurgaon','Rangmanch','Kurtis');
insert into `tb_preferences_details`(`col_userid`,`col_preferred_locations`,`col_preferred_businesses`,`col_preferred_categories`) values (3,'Gurgaon','Benetton','Western Outfits');
insert into `tb_preferences_details`(`col_userid`,`col_preferred_locations`,`col_preferred_businesses`,`col_preferred_categories`) values (4,'Noida','Biba',null);
