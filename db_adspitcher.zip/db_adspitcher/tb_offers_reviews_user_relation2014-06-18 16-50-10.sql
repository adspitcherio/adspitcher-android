USE db_adspitcher;

