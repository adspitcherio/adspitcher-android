USE db_adspitcher;

insert into `tb_user_profile_details`(`col_userid`,`col_userfistname`,`col_userlastname`,`col_usercurrentlocation`,`col_userimage`,`col_useremail`,`col_userdob`,`col_usercredits`,`col_userbadgelevel`) values (1,'Rachna','Khokhar','Gurgaon',nullnullSystem.Byte[],'rachnakhokhar@gmail.com','09/06/1984',10,1);
insert into `tb_user_profile_details`(`col_userid`,`col_userfistname`,`col_userlastname`,`col_usercurrentlocation`,`col_userimage`,`col_useremail`,`col_userdob`,`col_usercredits`,`col_userbadgelevel`) values (2,'Saumya','Pandey','Gurgaon',nullnullSystem.Byte[],'saumyapandey@gmail.com',null,10,1);
insert into `tb_user_profile_details`(`col_userid`,`col_userfistname`,`col_userlastname`,`col_usercurrentlocation`,`col_userimage`,`col_useremail`,`col_userdob`,`col_usercredits`,`col_userbadgelevel`) values (3,'Charu','Ramchandani','Gurgaon',nullnullSystem.Byte[],null,null,10,1);
insert into `tb_user_profile_details`(`col_userid`,`col_userfistname`,`col_userlastname`,`col_usercurrentlocation`,`col_userimage`,`col_useremail`,`col_userdob`,`col_usercredits`,`col_userbadgelevel`) values (4,'Monica','Arora','Gurgaon',nullnullSystem.Byte[],null,null,10,1);
