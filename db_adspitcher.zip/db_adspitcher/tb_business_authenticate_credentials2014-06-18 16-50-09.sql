USE db_adspitcher;

insert into `tb_business_authenticate_credentials`(`col_businessid`,`col_businessusername`,`col_businesspassword`) values (1,'adidas','test12345');
insert into `tb_business_authenticate_credentials`(`col_businessid`,`col_businessusername`,`col_businesspassword`) values (2,'benetton','test12345');
insert into `tb_business_authenticate_credentials`(`col_businessid`,`col_businessusername`,`col_businesspassword`) values (3,'rangmanch','test12345');
insert into `tb_business_authenticate_credentials`(`col_businessid`,`col_businessusername`,`col_businesspassword`) values (4,'biba','test12345');
